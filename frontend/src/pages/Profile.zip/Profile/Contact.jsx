import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebookF, faTwitter, faLinkedinIn } from "@fortawesome/free-brands-svg-icons";



export default function Contact(props){
    // Simulating the authenticated user ID
    const authenticatedUserId = 4; 

    // Check if the user_id prop matches the authenticated user ID
    // const isAuthorized = props.user_id === authenticatedUserId;
    const isAuthorized  = true;
    

      
      // console.log(contactInfoDataAPI)
    
  // START Contact-Info List
const contactInfoDataList = [
  { label: 'Email', value: 'example@example.com' },
  { label: 'Phone', value: '123-456-7890' },
  { label: 'Address', value: '123 Main St, City, State' },
];

const [contactInfoData, setContactInfoData] = useState(contactInfoDataList);
// console.log(contactInfoData)
const [newContactInfo, setNewContactInfo] = useState({
  label: '',
  value: ''
});

const [isEditMode, setIsEditMode] = useState(false);
const [editIndex, setEditIndex] = useState(null);

const handleContactInfoInputChange = (e) => {
  const { name, value } = e.target;
  setNewContactInfo((prevContactInfo) => ({
    ...prevContactInfo,
    [name]: value
  }));
};

const handleAddContactInfo = () => {
  if (newContactInfo.label && newContactInfo.value) {
    if (isEditMode) {
      const updatedData = [...contactInfoData];
      updatedData[editIndex] = newContactInfo;
      setContactInfoData(updatedData);
      setIsEditMode(false);
      setEditIndex(null);
    } else {
      setContactInfoData((prevData) => [...prevData, newContactInfo]);
    }
    setNewContactInfo({
      label: '',
      value: ''
    });
  }
};

const handleEditContactInfo = (index) => {
  setIsEditMode(true);
  setEditIndex(index);
  const contactInfo = contactInfoData[index];
  setNewContactInfo({
    label: contactInfo.label,
    value: contactInfo.value
  });
};

const handleDeleteContactInfo = (index) => {
  setContactInfoData((prevData) => {
    const updatedData = [...prevData];
    updatedData.splice(index, 1);
    return updatedData;
  });
  setIsEditMode(false);
  setEditIndex(null);
};
// END Contact Info


// Start Social Media

const [facebookUrlfromAPI, setFacebookUrlfromAPI] = useState('');
const [twitterUrlfromAPI , setTwitterUrlfromAPI]= useState('');
const [linkedinUrlfromAPI , setLinkedinUrlfromAPI]= useState('');

const [link, setLink] = useState({
  name: "",
  url: ""
});

const handleInputChange = (event) => {
  const { name, value } = event.target;
  setLink((prevLink) => ({
    ...prevLink,
    [name]: value
  }));
};

const handleSocialAddButtonClick = () => {
  // Send the link object to the backend
  axios
    .post("http://localhost:8087/api/profile/social/add", link, {
      headers: {
        "Content-Type": "application/json",
        Authorization:
          "Bearer " +
          "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw"
      }
    })
    .then((response) => {
      // Handle the response from the backend
      console.log(response.data);
    })
    .catch((error) => {
      // Handle any errors
      console.error(error);
    });

  // Clear the input fields after sending the data
  setLink({
    name: "",
    url: ""
  });
};
// End Social Media 

useEffect(() => {
  const fetchData = async () => {
    try {
      // Fetch the aboutText data from the API
      const response = await axios.get('http://localhost:8087/api/profile/'+authenticatedUserId ,{
        headers: {
          "Content-Type": "application/json",
          Authorization:
              "Bearer " +
              ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
            }}
            );
      console.log(response.data.data.socialLinks.facebook)
      setFacebookUrlfromAPI(response.data.data.socialLinks.facebook)
      setTwitterUrlfromAPI(response.data.data.socialLinks.twitter)
      setLinkedinUrlfromAPI(response.data.data.socialLinks.linkedin)


    } catch (error) {
      console.error("Error fetching about text:", error);
    }
  };

  fetchData();
}, []);


  return (
      <div>
        {isAuthorized ? (
          // MY PROFILE
          <div>
          <h2>Contact Information</h2>
          <ul className="contact-info-list">
            {contactInfoData.map((contactInfo, index) => (
              <li key={index}>
                <div>
                  <span className="label">{contactInfo.label}</span>
                  <span className="value">{contactInfo.value}</span>
                </div>
                <div>
                  {isEditMode && editIndex === index ? (
                    <>
                      <button className="update-button" onClick={handleAddContactInfo}>
                        Update
                      </button>
                      <button className="cancel-button" onClick={() => setIsEditMode(false)}>
                        Cancel
                      </button>
                    </>
                  ) : (
                    <button className="edit-button" onClick={() => handleEditContactInfo(index)}>
                      Edit
                    </button>
                  )}
                  <button className="delete-button" onClick={() => handleDeleteContactInfo(index)}>
                    Delete
                  </button>
                </div>
              </li>
            ))}
            <li>
              <input
              className="addlablel"
                type="text"
                name="label"
                value={newContactInfo.label}
                onChange={handleContactInfoInputChange}
                placeholder="Label"
              />
              <input
              className="addlablel"
                type="text"
                name="value"
                value={newContactInfo.value}
                onChange={handleContactInfoInputChange}
                placeholder="Value"
              />
              <button className="add-button" onClick={handleAddContactInfo}>
                {isEditMode ? 'Update' : 'Add'}
              </button>
            </li>
          </ul>
          <h2 style={{marginTop: '50px'}}>Social Media</h2>
              <div>
                  <input
                  className="input-url"
                  type="text"
                    name="name"
                  placeholder="Social Media Name Ex: facebook or witter or linkedin"
                  value={link.name}
                  onChange={handleInputChange}
                />
                <input
                className="input-url"
                  type="text"
                  name="url"
                  placeholder="URL"
                  value={link.url}
                  onChange={handleInputChange}
                />
                <button onClick={handleSocialAddButtonClick}className="add-button add-button-url">Add</button>
              </div>
              <div className="social-icons">
              <a href={`${facebookUrlfromAPI}`} className="f-facebook">
                <FontAwesomeIcon icon={faFacebookF} />
              </a>
              <a href={`${twitterUrlfromAPI}`} className="f-twitter">
                <FontAwesomeIcon icon={faTwitter} />
              </a>
              <a href={`${linkedinUrlfromAPI}`} className="f-linkedin">
                <FontAwesomeIcon icon={faLinkedinIn} />
              </a>
            </div>
        </div>
        ) : (
          // USER PROFILE
          <div>
              <h2>Contact Information</h2>
              <ul className="contact-info-list">
                {contactInfoData.map((item, index) => (
                  <li key={index}>
                    <span className="label">{item.label}:</span>
                    <span className="value">{item.value}</span>
                  </li>
                ))}
              </ul>
          <h2 style={{marginTop: '50px'}}>Social Media</h2>
              <div className="social-icons">
                  <a href={`${facebookUrlfromAPI}`} className="f-facebook">
                      <FontAwesomeIcon icon={faFacebookF} />
                    </a>
                  <a href={`${twitterUrlfromAPI}`} className="f-twitter">
                      <FontAwesomeIcon icon={faTwitter} />
                    </a>
                  <a href={`${linkedinUrlfromAPI}`} className="f-linkedin">
                  <FontAwesomeIcon icon={faLinkedinIn} />
                  </a>
              </div>
            </div>
        )}
      
    </div>
    
  )
}

















// import React from "react";
// import "../../styles/Profile.css"
// import { useState , useEffect} from "react";
// import axios from "axios";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faFacebookF, faTwitter, faLinkedinIn } from "@fortawesome/free-brands-svg-icons";



// export default function Education(props){
//     // Simulating the authenticated user ID
//     const authenticatedUserId = 4;
//     // Check if the user_id prop matches the authenticated user ID
//     // const isAuthorized = props.user_id === authenticatedUserId;
//     const isAuthorized  = true;

// // {
// //   "phone": "string",
// //   "telephone": "string",
// //   "email": "a@g.com",
// //   "address": "string"
// // }

// const [educationData, setEducationData] = useState([{}]);

// const [newEducation, setNewEducation] = useState({
//   phone: "",
//   telephone: "",
//   email:"" ,
//   address: ""
// });

// const [editEducationIndex, setEditEducationIndex] = useState(null);

// const handleEducationInputChange = (e) => {
//   const { name, value } = e.target;
//   setNewEducation((prevEducation) => ({
//     ...prevEducation,
//     [name]: value
//   }));
// };

// const handleAddEducation = async() => {
//   if (newEducation.phone && newEducation.telephone && newEducation.email&& newEducation.address) {
//     if (editEducationIndex !== null) {
//       // Update existing education
//       try {
//         // Send a POST request to update the aboutText in the API
//         const response = await axios.put('http://localhost:8087/api/profile/contactInfo/update' , newEducation ,{
//           headers: {
//             "Content-Type": "application/json",
//             Authorization:
//                 "Bearer " +
//                 ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
//               }}
//               );
//               console.log(response.data)
//               // setEducationData([newEducation])
//       } catch (error) {
//         console.log("Error saving skills:", error);
//       }
//       setEducationData((prevData) => {
//         const updatedData = [...prevData];
//         updatedData[editEducationIndex] = newEducation;
//         return updatedData;
//       });
//       setEditEducationIndex(null);
//     } else {
//       // Add new education
//       setEducationData((prevData) => [...prevData, newEducation]);
//     }

//     setNewEducation({
//       phone: "",
//       telephone: "",
//       email:"" ,
//       address: ""
//   });
//   }
// };

// const handleDeleteEducation = (index) => {
//   setEducationData((prevData) => {
//     const updatedData = [...prevData];
//     updatedData.splice(index, 1);
//     return updatedData;
//   });
// };

// const handleEditEducation = (index) => {
//   const educationToEdit = educationData[index];
//   setNewEducation(educationToEdit);
//   setEditEducationIndex(index);
// };




// // Start Social Media

// const [facebookUrlfromAPI, setFacebookUrlfromAPI] = useState('');
// const [twitterUrlfromAPI , setTwitterUrlfromAPI]= useState('');
// const [linkedinUrlfromAPI , setLinkedinUrlfromAPI]= useState('');

// const [link, setLink] = useState({
//   name: "",
//   url: ""
// });

// const handleInputChange = (event) => {
//   const { name, value } = event.target;
//   setLink((prevLink) => ({
//     ...prevLink,
//     [name]: value
//   }));
// };

// const handleSocialAddButtonClick = () => {
//   // Send the link object to the backend
//   axios
//     .post("http://localhost:8087/api/profile/social/add", link, {
//       headers: {
//         "Content-Type": "application/json",
//         Authorization:
//           "Bearer " +
//           "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw"
//       }
//     })
//     .then((response) => {
//       // Handle the response from the backend
//       console.log(response.data);
//     })
//     .catch((error) => {
//       // Handle any errors
//       console.error(error);
//     });

//   // Clear the input fields after sending the data
//   setLink({
//     name: "",
//     url: ""
//   });
// };
// // End Social Media 

// useEffect(() => {
//   const fetchData = async () => {
//     try {
//       // Fetch the aboutText data from the API
//       const response = await axios.get('http://localhost:8087/api/profile/'+authenticatedUserId ,{
//         headers: {
//           "Content-Type": "application/json",
//           Authorization:
//               "Bearer " +
//               ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
//             }}
//             );
//       setEducationData([response.data.data.contactInfo]);
//       // console.log(response.data.data.socialLinks.facebook)
//       setFacebookUrlfromAPI(response.data.data.socialLinks.facebook)
//       setTwitterUrlfromAPI(response.data.data.socialLinks.twitter)
//       setLinkedinUrlfromAPI(response.data.data.socialLinks.linkedin)


//     } catch (error) {
//       console.error("Error fetching about text:", error);
//     }
//   };

//   fetchData();
// }, []);


//   // phone: "",
//   // telephone: "",
//   // email:"" ,
//   // address: ""

//   return (
//       <div>
//         {isAuthorized ? (
//           // MY PROFILE
//           <div>

//               <h2>Education</h2>
//               <ul className="education-list">
//                 {educationData.map((education, index) => (
//                   <li key={index}>
//                     <div>
//                       <div className="institute name">{education.phone}</div>
//                       <div className="degree">{education.telephone}</div>
//                       <div className="from">{education.email}</div>
//                       <div className="to">{education.address}</div>
//                     </div>
//                     <div className="buttons-container">
//                       <button className="edit-button" onClick={() => handleEditEducation(index)}>
//                         Edit
//                       </button>
//                       <button className="delete-button" onClick={() => handleDeleteEducation(index)}>
//                         Delete
//                       </button>
//                     </div>
//                   </li>
//                 ))}
//                 <li>
//                 <input
//                     className="input-to-add"
//                     type="text"
//                     name="instituteName"
//                     value={newEducation.phone}
//                     onChange={handleEducationInputChange}
//                     placeholder="phone"
//                   />
//                 <input
//                     className="input-to-add"
//                     type="text"
//                     name="degree"
//                     value={newEducation.telephone}
//                     onChange={handleEducationInputChange}
//                     placeholder="telephone"
//                   />
                  
//                   <input
//                     className="input-to-add"
//                     type="email"
//                     name="from"
//                     value={newEducation.email}
//                     onChange={handleEducationInputChange}
//                     placeholder="email"
//                   />
//                   <input
//                     className="input-to-add"
//                     type="text"
//                     name="to"
//                     value={newEducation.address}
//                     onChange={handleEducationInputChange}
//                     placeholder="address"
//                   />
//                   <button className="add-button input-to-add" onClick={handleAddEducation}>
//                     {editEducationIndex !== null ? 'Update' : 'Add'}
//                   </button>
//                 </li>
//               </ul>
//               <h2 style={{marginTop: '50px'}}>Social Media</h2>
//                 <div>
//                   <input
//                     className="input-url"
//                     type="text"
//                     name="name"
//                     placeholder="Social Media Name"
//                     value={link.name}
//                     onChange={handleInputChange}
//                   />
//                   <input
//                   className="input-url"
//                     type="text"
//                     name="url"
//                     placeholder="URL"
//                     value={link.url}
//                     onChange={handleInputChange}
//                   />
//                   <button onClick={handleSocialAddButtonClick}className="add-button add-button-url">Add</button>
//                 </div>
//                 <div className="social-icons">
//                 <a href={`${facebookUrlfromAPI}`} className="f-facebook">
//                   <FontAwesomeIcon icon={faFacebookF} />
//                 </a>
//                 <a href={`${twitterUrlfromAPI}`} className="f-twitter">
//                   <FontAwesomeIcon icon={faTwitter} />
//                 </a>
//                 <a href={`${linkedinUrlfromAPI}`} className="f-linkedin">
//                   <FontAwesomeIcon icon={faLinkedinIn} />
//                 </a>
//               </div>
//             </div>
//         ) : (
//           // USER PROFILE
//           <div>
//                 <h2>Education</h2>
//                 <ul className="education-list">
//                   {educationData.map((item, index) => (
//                     <li key={index}>
//                       <p>{item.phone}</p>
//                       <h3>{item.telephone}</h3>
//                       <p>{item.email}</p>
//                       <p>{item.address}</p>
//                     </li>
//                   ))}
//                 </ul>
//                 <div className="social-icons">
//                     <a href={`${facebookUrlfromAPI}`} className="f-facebook">
//                       <FontAwesomeIcon icon={faFacebookF} />
//                     </a>
//                     <a href={`${twitterUrlfromAPI}`} className="f-twitter">
//                       <FontAwesomeIcon icon={faTwitter} />
//                     </a>
//                     <a href={`${linkedinUrlfromAPI}`} className="f-linkedin">
//                       <FontAwesomeIcon icon={faLinkedinIn} />
//                     </a>
//                 </div>
//             </div>
//         )}

        

//     </div>
    
//   )
// }