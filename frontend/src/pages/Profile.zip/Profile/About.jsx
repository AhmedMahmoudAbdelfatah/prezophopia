// import React from "react";
// import { useState } from "react";
// import "../../styles/Profile.css"




// export default function About(props){
//     // Simulating the authenticated user ID
//     const authenticatedUserId = '123'; 

//     // Check if the user_id prop matches the authenticated user ID
//     // const isAuthorized = props.user_id === authenticatedUserId;
//     const isAuthorized  = true;
  
// //Start About List
// const aboutItemsData = 'Lorem ipsum dolor sit, amet consectetur Lorem ipsum dolor sit, amet consectetur Lorem ipsum dolor sit, amet consectetur '

// const [aboutText, setAboutText] = useState(aboutItemsData);
// const [editMode, setEditMode] = useState(false);

// const handleAboutInputChange = (e) => {
//   setAboutText(e.target.value);
// };

// const handleEdit = () => {
//   setEditMode(true);
// };

// const handleSave = () => {
//   // Perform any save or update logic here
//   console.log('About text:', aboutText);
//   setEditMode(false);
// };


// //End About List
//   return (
//       <div>
//         {isAuthorized ? (
//           // MY PROFILE
//           <div>
//           <h2>About</h2>
//           <ul className="about-list">
//             <li>
//               {editMode ? (
//                 <textarea
//                   className="text-area"
//                   value={aboutText}
//                   onChange={handleAboutInputChange}
//                   placeholder="Enter your text here"
//                 />
//               ) : (
//                 <div className="text">{aboutText}</div>
//               )}
//               {editMode ? (
//                 <button className="save-btn" onClick={handleSave}>Save</button>
//               ) : (
//                 <button className="edit-btn" onClick={handleEdit}>Edit</button>
//               )}
//             </li>
//           </ul>
//         </div>
//         ) : (
//           // USER PROFILE
//           <div>
//             <h2>About</h2>
//             <ul className="about-list">
//               <li>
//                   <div className="text">{aboutText}</div>
//               </li>
//             </ul>
//           </div>
//         )}
      
//     </div>
    
//   )
// }






// ------------------------------------------------------------------------
import React, { useState, useEffect } from "react";
import axios from "axios";

export default function About(props) {
  const authenticatedUserId = 4;


    // Check if the user_id prop matches the authenticated user ID
    // const isAuthorized = props.user_id === authenticatedUserId;
    const isAuthorized  = true;

  const [aboutText, setAboutText] = useState("");
  const [editMode, setEditMode] = useState(false);

  const handleAboutInputChange = (e) => {
    setAboutText(e.target.value);
  };

  const handleEdit = () => {
    setEditMode(true);
  };

  const handleSave = async () => {
    try {
      // Send a POST request to update the aboutText in the API
      const response = await axios.put('http://localhost:8087/api/profile/update/bio?bio='+aboutText , {},{
        headers: {
          "Content-Type": "application/json",
          Authorization:
              "Bearer " +
              ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
            }}
            );
      // console.log(response.data)
      setEditMode(false);
    } catch (error) {
      console.log("Error saving about text:", error);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch the aboutText data from the API
        const response = await axios.get('http://localhost:8087/api/profile/'+authenticatedUserId ,{
          headers: {
            "Content-Type": "application/json",
            Authorization:
                "Bearer " +
                ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
              }}
              );
        setAboutText(response.data.data.bio);
        // console.log(response.data.data.bio)
      } catch (error) {
        console.error("Error fetching about text:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      {isAuthorized ? (
        <div>
          <h2>About</h2>
          <ul className="about-list">
            <li>
              {editMode ? (
                <textarea
                  className="text-area"
                  value={aboutText}
                  onChange={handleAboutInputChange}
                  placeholder="Enter your text here"
                />
              ) : (
                <div className="text">{aboutText}</div>
              )}
              {editMode ? (
                <button className="save-btn" onClick={handleSave}>
                  Save
                </button>
              ) : (
                <button className="edit-btn" onClick={handleEdit}>
                  Edit
                </button>
              )}
            </li>
          </ul>
        </div>
      ) : (
        <div>
          <h2>About</h2>
          <ul className="about-list">
            <li>
              <div className="text">{aboutText}</div>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
}