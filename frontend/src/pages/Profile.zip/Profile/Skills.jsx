// import React from "react";
// import { useState } from "react";
// import "../../styles/Profile.css"
// import axios from "axios";




// export default function Skills(props){
//     // Simulating the authenticated user ID
//     const authenticatedUserId = '123'; 

//     // Check if the user_id prop matches the authenticated user ID
//     // const isAuthorized = props.user_id === authenticatedUserId;
//     const isAuthorized  = true;
  
//   //START Skills LIST
//   const skillsData = ['JavaScript', 'React', 'HTML', 'CSS'];
//   const [skills, setSkills] = useState(skillsData);
//   const [newSkill, setNewSkill] = useState('');
  
//   const handleSkillsInputChange = (e) => {
//     setNewSkill(e.target.value);
//   };
  
//   const handleAddSkill = () => {
//     if (newSkill) {
//       setSkills([...skills, newSkill]);
//       setNewSkill('');
//     }
//   };
  
//   const handleDeleteSkill = (index) => {
//     const updatedSkills = [...skills];
//     updatedSkills.splice(index, 1);
//     setSkills(updatedSkills);
//   };

//   return (
//       <div>
//         {isAuthorized ? (
//           // MY PROFILE
//           <div>
//           <h2>Skills</h2>
//           <ul className="skills-list">
//             {skills.map((skill, index) => (
//               <li key={index}>
//                 <span className="text">{skill}</span>
//                 <button className="delete-button" onClick={() => handleDeleteSkill(index)}><i class="fa-solid fa-delete-left"></i></button>
//               </li>
//             ))}
//             <li className="add-li">
//               <input type="text" value={newSkill} onChange={handleSkillsInputChange} />
//               <button className="add-button" onClick={handleAddSkill}>Add</button>
//             </li>
//           </ul>
//         </div>
//         ) : (
//           // USER PROFILE
//           <div>
//               <h2>Skills</h2>
//               <ul className="skills-list">
//                 {skills.map((skill, index) => (
//                   <li key={index}>{skill}</li>
//                 ))}
//               </ul>
//             </div>
//         )}
      
//     </div>
    
//   )
// }
// //END Skills LIST














// --------------------------------------------------------
import React from "react";
import { useState , useEffect} from "react";
import axios from "axios";




export default function Skills(props){
    // Simulating the authenticated user ID
    const authenticatedUserId = 4;
    // Check if the user_id prop matches the authenticated user ID
    // const isAuthorized = props.user_id === authenticatedUserId;
    const isAuthorized  = true;
  
  //START Skills LIST
  const skillsData = ['JavaScript', 'React', 'HTML', 'CSS'];
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState('');
  




  const handleSkillsInputChange = (e) => {
    setNewSkill(e.target.value);
  };
  
  const handleAddSkill = async () => {
    if (newSkill) {
      setSkills([...skills, newSkill]);
      setNewSkill('');
      try {
        // Send a POST request to update the aboutText in the API
        const response = await axios.put('http://localhost:8087/api/profile/update/skills?skills='+newSkill , {},{
          headers: {
            "Content-Type": "application/json",
            Authorization:
                "Bearer " +
                ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
              }}
              );
              // console.log(response.data)
      } catch (error) {
        console.log("Error saving skills:", error);
      }
      
    }
  };
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch the aboutText data from the API
        const response = await axios.get('http://localhost:8087/api/profile/'+authenticatedUserId ,{
          headers: {
            "Content-Type": "application/json",
            Authorization:
                "Bearer " +
                ("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhaG1lZEBnbWFpbC5jb20iLCJqdGkiOiI0IiwiaWF0IjoxNjg2Njc4NjQ2LCJleHAiOjE2ODc1NDI2NDZ9.gectJVHyuqBn-GQ_vPfOWspsYapiQXn9yh5iBKLd2Nmrg3lSRw722Uuz078Q_ZMcD1vsOpKJKLQDlVyJZqFVrw")
              }}
              );
        setSkills(response.data.data.skills);
        // console.log(response.data.data.skills)
      } catch (error) {
        console.error("Error fetching about text:", error);
      }
    };

    fetchData();
  }, []);



  const handleDeleteSkill = (index) => {
    const updatedSkills = [...skills];
    updatedSkills.splice(index, 1);
    setSkills(updatedSkills);
  };

  return (
      <div>
        {isAuthorized ? (
          // MY PROFILE
          <div>
          <h2>Skills</h2>
          <ul className="skills-list">
            {skills.map((skill, index) => (
              <li key={index}>
                <span className="text">{skill}</span>
                <button className="delete-button" onClick={() => handleDeleteSkill(index)}><i class="fa-solid fa-delete-left"></i></button>
              </li>
            ))}
            <li className="add-li">
              <input type="text" value={newSkill} onChange={handleSkillsInputChange} />
              <button className="add-button" onClick={handleAddSkill}>Add</button>
            </li>
          </ul>
        </div>
        ) : (
          // USER PROFILE
          <div>
              <h2>Skills</h2>
              <ul className="skills-list">
                {skills.map((skill, index) => (
                  <li key={index}>{skill}</li>
                ))}
              </ul>
            </div>
        )}
      
    </div>
    
  )
}
//END Skills LIST
